-- The register's table.
--
-- Run it as the APPLICATION's own user, not as the administrator. The grant in
-- setup.sql gave `school` everything inside the `school` database, and creating
-- its own table is exactly what that means:
--
--   set -a; . school.env; set +a
--   MYSQL_PWD="$SCHOOL_PASSWORD" mysql -u school school -e "source schema.sql"
--
-- `source` is the mysql client's own command for running a file, so it needs no
-- shell feature and works the same typed at a `mysql>` prompt. A redirection --
-- `... mysql -u school school < schema.sql` -- does the same job; the client
-- names the FILE in its error messages and the shell does not, which is the
-- difference you notice when a script fails halfway.
--
-- MYSQL_PWD as a one-command prefix, so the password is in the environment of
-- that one process and never on a command line for `ps` to show. Do NOT pipe it
-- into `mysql -p`: the client prefers to read a password from /dev/tty and only
-- falls back to stdin when there is no terminal at all, so at a real keyboard
-- that form waits for ever.
--
-- This file owns the SHAPE of the data. seed.sql owns the data itself, and the
-- two are separate on purpose: a schema change and a data load are different
-- operations with different risks, and you will meet deployments where one is
-- allowed and the other is not.
--
-- The names here are the TABLE's — student_id, first_name. The API calls them
-- studentId and firstName; Prisma maps one onto the other. Both are correct,
-- and they are two views of one table.
--
-- NO COLLATE CLAUSE, deliberately. Prisma emits `utf8mb4_unicode_ci` on every
-- MySQL table it generates, and on MySQL 8 that is a downgrade: the server's
-- own default is utf8mb4_0900_ai_ci — Unicode 9.0 and NO PAD — while
-- utf8mb4_unicode_ci is Unicode 5.2 and PAD SPACE, under which every emoji
-- compares equal to every other emoji and 'a ' = 'a' is true. Leaving it out
-- lets the table inherit the database's collation, which setup.sql sets
-- deliberately.

CREATE TABLE students (
    student_id VARCHAR(11) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name  VARCHAR(50) NOT NULL,
    major      VARCHAR(20) NOT NULL,

    PRIMARY KEY (student_id)
) DEFAULT CHARACTER SET utf8mb4;
