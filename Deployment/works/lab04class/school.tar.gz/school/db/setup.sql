-- The database this application needs, and the user it connects as.
--
-- Run it ONCE, as the server's administrator:
--
--   sudo mysql < setup.sql
--
-- It prints the password the SERVER chose for the new user, and that is the
-- only time it is ever shown. Put it in db/school.env before you do anything
-- else, exactly as printed.
--
-- This is the first of the three scripts in this directory, and the only one
-- that needs the administrator. schema.sql makes the table and seed.sql fills
-- it, and both of those run as the user this one creates -- which is what the
-- GRANT below is for.
--
-- A script rather than statements typed at a prompt, for the same reason the
-- seed beside it is a script: it can be read before it is run, reviewed by
-- somebody else, and repeated on the next machine identically. A deployment
-- assembled by typing is one that nobody can reproduce -- including you, in six
-- months, at the worst possible moment.
--
-- Run it twice and the second run stops on an error. That is deliberate: none
-- of these statements is idempotent, and failing loudly beats quietly replacing
-- a credential that something is already using.

CREATE DATABASE school CHARACTER SET utf8mb4;

CREATE USER 'school'@'localhost' IDENTIFIED BY RANDOM PASSWORD;

-- `school.*` is the scope, and the whole point: this user may do anything it
-- likes inside its own database and has no privilege of any kind outside it.
GRANT ALL PRIVILEGES ON school.* TO 'school'@'localhost';
