-- The register's starting data.
--
-- Run this AFTER schema.sql has made the table, and as the same user:
--
--   set -a; . school.env; set +a
--   MYSQL_PWD="$SCHOOL_PASSWORD" mysql -u school school -e "source seed.sql"
--
-- See the note at the top of schema.sql for both of these: why `source` rather
-- than a redirection (either works), and why the password goes in through
-- MYSQL_PWD rather than down a pipe into `mysql -p` (only one of those works).
--
-- schema.sql owns the SHAPE of the data; this file owns the data itself. See
-- the note at the top of schema.sql for why they are two files.
--
-- It starts with a DELETE, so running it twice is safe and running it on a
-- register somebody has been using is not. Read a script before you run it.

DELETE FROM students;

INSERT INTO students (student_id, first_name, last_name, major) VALUES
  ('68130500170', 'SOMCHAI', 'JAIDEE',  'IT'),
  ('68130500280', 'PETER',   'CHU',     'CS'),
  ('68130500460', 'SOMSRI',  'RAKREAN', 'DSI');
