// The register page. It reads its configuration from `window.INT134`, which
// `config.js` sets, and it knows nothing else about where it is deployed.

const cfg = window.INT134 ?? {};
const url = cfg.studentsUrl ?? "";

const tbody = document.querySelector("#students tbody");
const listStatus = document.getElementById("list-status");
const formStatus = document.getElementById("form-status");

document.getElementById("student-id").textContent = cfg.studentId || "(not configured)";
document.getElementById("source").textContent = url || "(not configured)";

function say(el, text, isError = false) {
  el.textContent = text;
  el.hidden = !text;
  el.classList.toggle("error", isError);
}

function render(students) {
  tbody.replaceChildren();
  for (const s of students) {
    const tr = document.createElement("tr");
    for (const field of ["studentId", "firstName", "lastName", "major"]) {
      const td = document.createElement("td");
      td.textContent = s[field] ?? "";
      tr.append(td);
    }
    tbody.append(tr);
  }
  say(listStatus, students.length ? "" : "Nobody is on the register yet.");
}

async function load() {
  if (!url) return say(listStatus, "studentsUrl is not set in config.js", true);
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`the server answered ${res.status}`);
    render(await res.json());
  } catch (err) {
    say(listStatus, `Could not load the register: ${err.message}`, true);
  }
}

document.getElementById("student-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.target;
  const body = Object.fromEntries(
    ["studentId", "firstName", "lastName", "major"].map((k) => [k, form[k].value.trim()]),
  );
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const detail = await res.json().catch(() => ({}));
      throw new Error(detail.error ?? `the server answered ${res.status}`);
    }
    form.reset();
    say(formStatus, "Added.");
    await load();
  } catch (err) {
    say(formStatus, `Could not add: ${err.message}`, true);
  }
});

load();
