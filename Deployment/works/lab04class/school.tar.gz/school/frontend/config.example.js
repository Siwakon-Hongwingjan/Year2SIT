// Copy this file to `config.js` and fill both values in.
//
//   cp config.example.js config.js
//
// `config.js` is deliberately NOT in git: it is different on every deployment,
// which is what configuration means. Committing it would put one machine's
// settings into everybody's checkout.

window.INT134 = {
  // Your 11-digit student number.
  studentId: "",

  // Where the register comes from.
  //
  // Class 4 does not deploy this page at all — the API is reached with `curl`.
  // Class 5 puts nginx in front of both, and this becomes the path the proxy
  // answers on. Your sheet says what to put here.
  studentsUrl: "/school/api/students",
};
