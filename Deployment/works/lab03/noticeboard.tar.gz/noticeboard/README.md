# INT134 Noticeboard

A very small web application: a list of short notices, and a form to add one.

It exists to be **deployed**, not to be read. You are not expected to modify the
JavaScript, and none of the coursework asks you to.

## What is in here

```
frontend/     the page. Plain HTML, CSS and JavaScript — no build step, no npm.
              A web server hands these files out exactly as they are.
backend/      a REST API over the notices, written with Express and Prisma,
              storing them in MySQL.
```

## How it is configured

Nothing here knows which machine it is on. Two files supply that, and neither
ships with the application, because they differ on every deployment:

| You create | From | It holds |
|---|---|---|
| `frontend/config.js` | `frontend/config.example.js` | your student number, and where the notices come from |
| `backend/.env` | `backend/.env.example` | the database connection, the port, the address to listen on |

Changing where this application gets its data is a change to `config.js` — one
line — and nothing else. That is the point of the design.

## The API

| Method | Path | Does |
|---|---|---|
| `GET` | `/api/health` | reports that the service is up, and whose it is |
| `GET` | `/api/notices` | the notices, newest first |
| `POST` | `/api/notices` | add one — JSON body with `author` and `message` |
| `DELETE` | `/api/notices/:id` | remove one |

## Requirements

Node.js 20 or newer, and MySQL 8, for the backend only. The frontend needs
neither: it is three files and a web server.
