// INT134 noticeboard API.
//
// Everything that differs between one deployment and the next is read from the
// environment and nothing else. There is no development branch, no NODE_ENV
// switch, and no hostname special-case in this file: if the behaviour has to
// change, the configuration changes.
//
// Logs go to stdout. Under systemd that lands in the journal; in a container it
// lands in `docker logs`. Writing to a log file would break both.

import express from "express";
import cors from "cors";
import { PrismaClient } from "@prisma/client";

const PORT = Number(process.env.PORT ?? 3000);

// 127.0.0.1 by default, so exposing this service to the network is something
// you have to ASK for rather than something you get by forgetting.
const HOST = process.env.HOST ?? "127.0.0.1";

const STUDENT_ID = process.env.STUDENT_ID ?? "";
const CORS_ORIGIN = process.env.CORS_ORIGIN ?? "";

const prisma = new PrismaClient();
const app = express();

app.disable("x-powered-by");
app.use(express.json({ limit: "8kb" }));

// Cross-origin requests are refused unless CORS_ORIGIN names who may make them.
// Unset is the safe state and the default. Set it and this middleware adds the
// Access-Control-Allow-Origin header the browser is looking for.
if (CORS_ORIGIN) {
  app.use(cors({ origin: CORS_ORIGIN }));
  console.log(`cors: allowing ${CORS_ORIGIN}`);
} else {
  console.log("cors: disabled (CORS_ORIGIN is not set)");
}

app.use((req, _res, next) => {
  console.log(`${req.method} ${req.originalUrl}`);
  next();
});

// Is this service up, and whose is it? The student id comes from the
// environment, so one deployment cannot be passed off as another's.
app.get("/api/health", (_req, res) => {
  res.json({ ok: true, student: STUDENT_ID, time: new Date().toISOString() });
});

app.get("/api/notices", async (_req, res, next) => {
  try {
    res.json(await prisma.notice.findMany({ orderBy: { id: "desc" }, take: 100 }));
  } catch (err) {
    next(err);
  }
});

app.post("/api/notices", async (req, res, next) => {
  const author = String(req.body?.author ?? "").trim();
  const message = String(req.body?.message ?? "").trim();
  if (!author || !message) {
    return res.status(400).json({ error: "author and message are both required" });
  }
  try {
    const notice = await prisma.notice.create({
      data: { author: author.slice(0, 60), message: message.slice(0, 200) },
    });
    res.status(201).json(notice);
  } catch (err) {
    next(err);
  }
});

app.delete("/api/notices/:id", async (req, res, next) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) {
    return res.status(400).json({ error: "id must be a whole number" });
  }
  try {
    await prisma.notice.delete({ where: { id } });
    res.status(204).end();
  } catch (err) {
    if (err?.code === "P2025") return res.status(404).json({ error: "no such notice" });
    next(err);
  }
});

app.use((_req, res) => res.status(404).json({ error: "no such endpoint" }));

// The message goes to the log; the client is told only that it failed. A stack
// trace in an HTTP response is a gift to whoever is probing you.
app.use((err, _req, res, _next) => {
  console.error("request failed:", err);
  res.status(500).json({ error: "internal error" });
});

const server = app.listen(PORT, HOST, () => {
  console.log(`noticeboard api listening on ${HOST}:${PORT}`);
  if (!STUDENT_ID) console.warn("warning: STUDENT_ID is not set");
});

// systemd stops a service by sending SIGTERM and waiting — the signal from
// class 2. Closing the listener and the database pool here is what makes
// `systemctl restart` quick and clean instead of a 90-second timeout.
for (const signal of ["SIGTERM", "SIGINT"]) {
  process.on(signal, () => {
    console.log(`${signal} received, shutting down`);
    server.close(async () => {
      await prisma.$disconnect();
      process.exit(0);
    });
  });
}
