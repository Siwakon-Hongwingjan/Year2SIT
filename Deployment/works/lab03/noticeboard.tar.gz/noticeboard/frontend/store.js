// Where the notices come from.
//
// There is ONE code path here and no branching on environment. The store reads
// and writes `window.INT134.noticesUrl`, and that single value is the whole
// difference between this application serving a file and this application
// talking to an API. Nothing else in the frontend changes, ever.
//
// That is deliberate: when the deployment changes and something breaks, the
// frontend is not a suspect, because it did not change.

(function (global) {
  "use strict";

  function config() {
    const c = global.INT134;
    if (!c || !c.noticesUrl) {
      throw new Error(
        "config.js is missing or incomplete — copy config.example.js to " +
        "config.js and fill it in"
      );
    }
    return c;
  }

  // Both calls report failure the same way: an Error carrying the HTTP status,
  // so the page can say what the server actually answered rather than "failed".
  // A deployment problem is diagnosed from the status code, so it must survive
  // all the way to the screen.
  function httpError(response) {
    const err = new Error(`${response.status} ${response.statusText}`.trim());
    err.status = response.status;
    return err;
  }

  async function list() {
    const response = await fetch(config().noticesUrl, {
      headers: { Accept: "application/json" },
      cache: "no-store",
    });
    if (!response.ok) throw httpError(response);
    const data = await response.json();
    if (!Array.isArray(data)) {
      throw new Error("the source returned something that is not a list");
    }
    return data;
  }

  async function add(notice) {
    const response = await fetch(config().noticesUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify(notice),
    });
    if (!response.ok) throw httpError(response);
    return response.json();
  }

  global.NoticeStore = { list, add, source: () => config().noticesUrl };
})(window);
