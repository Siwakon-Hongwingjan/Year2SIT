// Rendering and wiring. Nothing here knows where the data comes from — that is
// store.js's single job — so this file is the same in every deployment.

(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const noticesEl = $("notices");
  const listStatus = $("list-status");
  const formStatus = $("form-status");
  const form = $("notice-form");

  function status(el, text, kind) {
    el.textContent = text;
    el.className = "status" + (kind ? " " + kind : "");
    el.hidden = !text;
  }

  function formatDate(value) {
    if (!value) return "";
    const d = new Date(value);
    return isNaN(d) ? String(value) : d.toLocaleString();
  }

  function render(notices) {
    noticesEl.replaceChildren();
    if (!notices.length) {
      status(listStatus, "No notices yet.");
      return;
    }
    status(listStatus, "");
    for (const n of notices) {
      const li = document.createElement("li");

      const msg = document.createElement("p");
      msg.className = "message";
      msg.textContent = n.message ?? "";

      const meta = document.createElement("p");
      meta.className = "meta";
      meta.textContent = `${n.author ?? "anonymous"} · ${formatDate(n.createdAt)}`;

      li.append(msg, meta);
      noticesEl.append(li);
    }
  }

  // The status code is the diagnosis, so it is what the reader is shown.
  // 405 in particular is not an error in this application: it is a static file
  // server correctly refusing to accept a POST, which is the whole reason the
  // next part of this course exists.
  function explain(err) {
    if (err.status === 405) {
      return "405 Method Not Allowed — this deployment serves files and cannot " +
             "accept new notices. Storing data needs something more than a web server.";
    }
    if (err.status === 404) {
      return "404 Not Found — nothing is published at " + window.NoticeStore.source() + ".";
    }
    if (err.status) return "The server answered " + err.message + ".";
    // No status at all: the request never completed. Blocked by the browser
    // (CORS), refused, or nothing listening — the console has the reason.
    return "The request did not complete: " + err.message +
           ". Open the browser console and the network tab for the reason.";
  }

  async function refresh() {
    try {
      render(await window.NoticeStore.list());
    } catch (err) {
      status(listStatus, explain(err), "error");
    }
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const notice = {
      author: $("author").value.trim(),
      message: $("message").value.trim(),
    };
    if (!notice.author || !notice.message) return;

    status(formStatus, "Posting…");
    try {
      await window.NoticeStore.add(notice);
      status(formStatus, "Posted.", "ok");
      $("message").value = "";
      await refresh();
    } catch (err) {
      status(formStatus, explain(err), "error");
    }
  });

  // The student id is rendered from config.js so that one deployment cannot be
  // passed off as another's.
  const cfg = window.INT134 || {};
  $("student-id").textContent = cfg.studentId || "(not configured)";
  $("source").textContent = cfg.noticesUrl || "(not configured)";

  refresh();
})();
