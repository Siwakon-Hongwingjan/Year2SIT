// Copy this file to `config.js` and fill both values in.
//
//   cp config.example.js config.js
//
// `config.js` is deliberately NOT in git: it is different on every deployment,
// which is what configuration means. Committing it would put one machine's
// settings into everybody's checkout.
//
// noticesUrl — where the notices come from. It is the only thing that changes
// when this application moves from serving a file to talking to an API.

window.INT134 = {
  // Your 11-digit student number.
  studentId: "",

  // Class 3: the data file this site ships with.
  //   "/data/notices.json"
  //
  // Later, the API — your instructor's sheet says when and what to put here.
  noticesUrl: "/data/notices.json",
};
